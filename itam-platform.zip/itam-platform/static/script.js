/* -----------------------------------------------------------------------
   System Monitoring & IT Asset Management Platform
   Author: Aditya Kumar | agile.aditya.kumar@gmail.com
   ----------------------------------------------------------------------- */

// ---------------- Tab Navigation ----------------
document.querySelectorAll(".tab-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".tab-content").forEach(c => c.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById(btn.dataset.tab).classList.add("active");
  });
});

// ---------------- Usage Chart ----------------
const ctx = document.getElementById("usageChart").getContext("2d");
const usageChart = new Chart(ctx, {
  type: "line",
  data: {
    labels: [],
    datasets: [
      { label: "CPU %", data: [], borderColor: "#2563eb", tension: 0.3 },
      { label: "RAM %", data: [], borderColor: "#22c55e", tension: 0.3 },
      { label: "Disk %", data: [], borderColor: "#f59e0b", tension: 0.3 },
    ],
  },
  options: {
    responsive: true,
    scales: { y: { min: 0, max: 100 } },
    plugins: { legend: { labels: { color: "#e2e8f0" } } },
  },
});

const MAX_POINTS = 15;

async function fetchSystemStats() {
  const res = await fetch("/api/system-stats");
  const data = await res.json();

  document.getElementById("cpuVal").textContent = data.cpu_percent + "%";
  document.getElementById("ramVal").textContent = data.ram_percent + "%";
  document.getElementById("diskVal").textContent = data.disk_percent + "%";
  document.getElementById("uptimeVal").textContent = data.uptime;
  document.getElementById("netSent").textContent = data.network_sent_mb;
  document.getElementById("netRecv").textContent = data.network_recv_mb;

  usageChart.data.labels.push(data.timestamp);
  usageChart.data.datasets[0].data.push(data.cpu_percent);
  usageChart.data.datasets[1].data.push(data.ram_percent);
  usageChart.data.datasets[2].data.push(data.disk_percent);

  if (usageChart.data.labels.length > MAX_POINTS) {
    usageChart.data.labels.shift();
    usageChart.data.datasets.forEach(ds => ds.data.shift());
  }
  usageChart.update();
}

async function fetchSummary() {
  const res = await fetch("/api/summary");
  const data = await res.json();
  document.getElementById("totalAssets").textContent = data.total_assets;
  document.getElementById("activeAssets").textContent = data.active_assets;
  document.getElementById("maintAssets").textContent = data.maintenance_assets;
  document.getElementById("totalAlerts").textContent = data.total_alerts;
}

// ---------------- Alerts ----------------
async function fetchAlerts() {
  const res = await fetch("/api/alerts");
  const data = await res.json();
  const list = document.getElementById("alertsList");
  list.innerHTML = "";

  if (data.length === 0) {
    list.innerHTML = "<li>No alerts yet. All systems normal ✅</li>";
    return;
  }

  data.forEach(alert => {
    const li = document.createElement("li");
    li.className = alert.severity;
    li.innerHTML = `<span>${alert.message}</span><span class="time">${alert.created_at}</span>`;
    list.appendChild(li);
  });
}

// ---------------- Assets CRUD ----------------
const modal = document.getElementById("assetModal");
const modalTitle = document.getElementById("modalTitle");

document.getElementById("addAssetBtn").addEventListener("click", () => {
  clearForm();
  modalTitle.textContent = "Add Asset";
  modal.classList.remove("hidden");
});

document.getElementById("cancelAssetBtn").addEventListener("click", () => {
  modal.classList.add("hidden");
});

function clearForm() {
  document.getElementById("assetId").value = "";
  document.getElementById("assetName").value = "";
  document.getElementById("assetType").value = "Laptop";
  document.getElementById("assetOwner").value = "";
  document.getElementById("assetStatus").value = "Active";
  document.getElementById("assetLocation").value = "";
  document.getElementById("assetDate").value = "";
}

document.getElementById("saveAssetBtn").addEventListener("click", async () => {
  const id = document.getElementById("assetId").value;
  const payload = {
    asset_name: document.getElementById("assetName").value,
    asset_type: document.getElementById("assetType").value,
    owner: document.getElementById("assetOwner").value,
    status: document.getElementById("assetStatus").value,
    location: document.getElementById("assetLocation").value,
    purchase_date: document.getElementById("assetDate").value,
  };

  if (!payload.asset_name) {
    alert("Please enter an asset name.");
    return;
  }

  if (id) {
    await fetch(`/api/assets/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
  } else {
    await fetch("/api/assets", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
  }

  modal.classList.add("hidden");
  loadAssets();
  fetchSummary();
});

async function loadAssets() {
  const res = await fetch("/api/assets");
  const assets = await res.json();
  const tbody = document.getElementById("assetsTableBody");
  tbody.innerHTML = "";

  assets.forEach(asset => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${asset.asset_name}</td>
      <td>${asset.asset_type}</td>
      <td>${asset.owner || "-"}</td>
      <td><span class="status-badge status-${asset.status}">${asset.status}</span></td>
      <td>${asset.location || "-"}</td>
      <td>${asset.purchase_date || "-"}</td>
      <td>
        <button class="btn" onclick="editAsset(${asset.id})">Edit</button>
        <button class="btn danger" onclick="deleteAsset(${asset.id})">Delete</button>
      </td>
    `;
    tbody.appendChild(tr);
  });

  window._assetsCache = assets;
}

function editAsset(id) {
  const asset = window._assetsCache.find(a => a.id === id);
  if (!asset) return;
  document.getElementById("assetId").value = asset.id;
  document.getElementById("assetName").value = asset.asset_name;
  document.getElementById("assetType").value = asset.asset_type;
  document.getElementById("assetOwner").value = asset.owner || "";
  document.getElementById("assetStatus").value = asset.status;
  document.getElementById("assetLocation").value = asset.location || "";
  document.getElementById("assetDate").value = asset.purchase_date || "";
  modalTitle.textContent = "Edit Asset";
  modal.classList.remove("hidden");
}

async function deleteAsset(id) {
  if (!confirm("Delete this asset?")) return;
  await fetch(`/api/assets/${id}`, { method: "DELETE" });
  loadAssets();
  fetchSummary();
}

// ---------------- Init ----------------
function refreshAll() {
  fetchSystemStats();
  fetchSummary();
  fetchAlerts();
}

refreshAll();
loadAssets();
setInterval(refreshAll, 3000);
